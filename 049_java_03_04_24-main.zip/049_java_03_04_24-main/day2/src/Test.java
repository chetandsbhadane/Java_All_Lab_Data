/*
4.5  Create a separate Driver(main)  class(for UI )  , "TestPoint" , with main(..)

4.6  Accept x,y co-ordinates for 2 points n store the co-ordinates
4.7  Display x,y co-ordinates of both of the points plotted  (using show() method) 

4.8  (Optional work)
Find out if the points  are same or different (Hint : isEqual)
Print the message accordingly. (print SAME or DIFFERENT)
If points are not same , display distance between these 2 points.
*/

class Test{

	private double x;
	private double y;

	public Test(double X, double Y){
		x = X;
		y = Y;
	}

	public String show(){
		return "x = " + this.x + " " + " y = " + this.y;
	}
	
	public boolean isEqaul(Test obj){
		return (this.x == obj.x && this.y == obj.y);	
	}


	public double calculateDistance(Test obj){ //d=√((x2 – x1)² + (y2 – y1)²).
		return Math.sqrt(Math.pow(obj.x - x,2) + Math.pow(obj.y-y,2));
	}
}