/*4. Hands on
(Currently place all the classes in the default un named package)

Create a  class Point2D   for representing a point in x-y co-ordinate system.

4.1 Create a parameterized constructor to accept x & y co-ords.

4.2 Add  show() method  --to return point's x & y co-ords
eg : public String show() {.....}

4.3 (Optional work)
Add a non static  , isEqual method to Point2D class : boolean returning method : must return 
true if both points are having 
same x,y co-ords or false otherwise.

4.4 (Optional work)
Add a non static method , calculateDistance , to calc distance between 2 points
Hint : use distance formula. d=√((x2 – x1)² + (y2 – y1)²).

eg : In Tester :
double distance=p1.calculateDistance(p2);

*/
class Point2D{
	private double x;
	private double y;
	
	public Point2D(double X,double y){
		x = X;
		this.y = y;
	}

	public String show(){
		return "x = " + this.x + " "+"y = " + this.y;
	}

	public boolean isEqual(Point2D obj){
		if(obj.x == this.x && obj.y == this.y){
			return true;
		}
		return false;
	}

	public double calculateDistance(Point2D obj){ //d=√((x2 – x1)² + (y2 – y1)²).
		return Math.sqrt(Math.pow(obj.x - x,2) + Math.pow(obj.y-y,2));
	}
}

class Tester{
	public static void main(String[] args){
		Point2D p1=new Point2D(10,40);
		Point2D p2=new Point2D(80,50);
		
		System.out.println(p1.isEqual(p2));
		System.out.println(p2.isEqual(p1));
		
		System.out.println(p1.calculateDistance(p2));
	}
}