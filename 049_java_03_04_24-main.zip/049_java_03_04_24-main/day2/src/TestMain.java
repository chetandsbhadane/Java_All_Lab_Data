/*
4.5  Create a separate Driver(main)  class(for UI )  , "TestPoint" , with main(..)

4.6  Accept x,y co-ordinates for 2 points n store the co-ordinates
4.7  Display x,y co-ordinates of both of the points plotted  (using show() method) 

4.8  (Optional work)
Find out if the points  are same or different (Hint : isEqual)
Print the message accordingly. (print SAME or DIFFERENT)
If points are not same , display distance between these 2 points.
*/

import java.util.Scanner;
class TestMain{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		Test t1 = new Test(sc.nextDouble(),sc.nextDouble());
		Test t2 = new Test(sc.nextDouble(),sc.nextDouble());

		//System.out.println(t1.show());
		System.out.println(t1.isEqaul(t2));

		System.out.println(t1.calculateDistance(t2));
	}
	
}