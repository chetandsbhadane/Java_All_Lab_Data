package custom_exception;
import  static custom_exception.VehiclesTypes.*;

public class FuelValidation {
	
	public static void validateFuel(String fuel) throws UnsupportedFuelTypeException {
		
		for(VehiclesTypes a : values()) {
		    if(fuel.equalsIgnoreCase(a.toString())) {
		        System.out.println("You are running on "+fuel);
		        return;
		    }
		}
	    throw new UnsupportedFuelTypeException("Fuel type of Vehicle is Incompatible");
	}
}
