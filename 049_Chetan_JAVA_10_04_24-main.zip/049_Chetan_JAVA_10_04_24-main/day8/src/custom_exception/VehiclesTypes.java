package custom_exception;
public enum VehiclesTypes {
	PETROL, CNG, EV;
	
	
 }
