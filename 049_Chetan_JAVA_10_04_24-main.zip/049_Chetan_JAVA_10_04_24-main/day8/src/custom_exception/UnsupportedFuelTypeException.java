package custom_exception;

@SuppressWarnings("serial")
public class UnsupportedFuelTypeException extends Exception {
	public UnsupportedFuelTypeException(String msg) {
		super(msg);
	}
}
