package custom_exception;
import java.util.Date;
public class LicenseValidateRule {
	public static Date d = new Date();

	public static void validateLicense(Date licenceDate) throws LicenseExpireException {
		if (d.after(licenceDate)) {
            throw new LicenseExpireException("Your Licence is expired!");
        } else {
            System.out.println("The license date is not expired.");
        }
	}
}
