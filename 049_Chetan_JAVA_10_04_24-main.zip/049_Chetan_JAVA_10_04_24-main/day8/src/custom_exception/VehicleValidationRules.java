package custom_exception;

public class VehicleValidationRules {

	public static final int MIN_SPEED;
	public static final int MAX_SPEED;
	
	static {
		MIN_SPEED = 40;
		MAX_SPEED = 80;
	}
	
	public static void validateSpeed(int speed) throws SpeedOutOfRangeException {
		if(speed < MIN_SPEED) 
			throw new SpeedOutOfRangeException("Speed is too low!, Please shift to the slower lane.");
		else if(speed > MAX_SPEED)
			throw new SpeedOutOfRangeException("Control Your Speed!, You are going to fast.");
		System.out.println("Your speed is in range, You are an Excellent driver.");
	}
}
