package custom_exception;

@SuppressWarnings("serial")
public class LicenseExpireException extends Exception{
	public LicenseExpireException(String msg) {
		super(msg);
	}
}
