package tester;
import static custom_exception.VehiclesTypes.values;
import static custom_exception.FuelValidation.*;
import java.util.Scanner;

import custom_exception.VehiclesTypes;

public class TestFuelType {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in)) {
			System.out.println("This Fuel Options are available:  ");
			for(VehiclesTypes a : values()) 
				System.out.println(a);
			System.out.println("Enter the fuel : ");
			validateFuel(sc.next().toLowerCase());
		}
		catch (Exception e) {
			System.out.println(e);
		}

	}

}
