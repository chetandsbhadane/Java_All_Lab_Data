package tester;
import static custom_exception.VehicleValidationRules.validateSpeed;
import java.util.Scanner;
public class TestValidateSpeed {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the current speed : ");
			validateSpeed(sc.nextInt());	
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}

}
