package tester;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

import static custom_exception.LicenseValidateRule.*;

public class TestLicense {

	public static void main(String[] args) {
       

        try(Scanner sc = new Scanner(System.in)){
        	System.out.println("Enter your license date in YYYY-MM-DD format : ");
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date expiryDate = sdf.parse(sc.next());
            validateLicense(expiryDate);
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
