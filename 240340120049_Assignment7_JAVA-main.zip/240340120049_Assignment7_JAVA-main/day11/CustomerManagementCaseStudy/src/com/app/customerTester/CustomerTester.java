package com.app.customerTester;

import java.util.Scanner;

import java.util.ArrayList;
import com.app.customer.Customer;
import com.app.customer.CustomerFunctions;
import com.app.validateInputs.ValidateAllInputs;

/*
Typical  Options
1. Sign up (customer registration)
Accept customer details
Validate all inputs.
In case of successful validations , display customer details via toString or displat error mesg via custom exception.

2. Sign in (login)
i/p : email n password
o/p : Successful login message or error message(Invalid email or password -via custom exception) */
public class CustomerTester {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			ArrayList<Customer> custList = new ArrayList<>();
			int ch = 0;
			do {
				System.out.println("1.Sign-Up\n2.Sign-In\n3.Change Pass\n4.Unsuscribe Acc\n5.DisplayAll\n0.exit");
				ch = sc.nextInt();
				try {
					switch (ch) {
					case 1:
						System.out.println(
								"Enter fName, lName, email, pass, regAmt, dob, plan(SILVER,GOLD,DIAMOND,PLATINUM)");
						Customer cust = ValidateAllInputs.validateInputs(sc.next(), sc.next(), sc.next(), sc.next(),
								sc.nextDouble(), sc.next(), sc.next());
						custList.add(cust);
						break;

					case 2:
						System.out.println("Enter Email and pass for sign-in");
						Customer cust2 = CustomerFunctions.signIn(sc.next(), sc.next(), custList);
						System.out.println(cust2);

						break;
						
// 3. Change password
//	i/p : email n old password n new password
//	o/p : Successful password updation  or error message(Invalid email or password -via custom exception)
					case 3:
						System.out.println("Enter email id, old pass and new pass");
						CustomerFunctions.changePass(sc.next(),sc.next(), sc.next(), custList);
						System.out.println("Pass has been changed..");
						break;
						
					case 4:
//						4. Un subscribe customer i/p : customer email
						System.out.println("Enter email id to remove acc..");
						Customer cust4 = CustomerFunctions.findByEmail(sc.next(), custList);
						custList.remove(cust4);
						System.out.println("Customer ahs been removed!!");
						break;
					case 5:
						for (Customer c : custList) {
							System.out.println(c);
						}
						break;
					}
				} catch (Exception e) {
					sc.nextLine();
					e.printStackTrace();
					System.out.println(e);
					System.out.println("try again..");
				}

			} while (ch != 0);

		}
	}
}
