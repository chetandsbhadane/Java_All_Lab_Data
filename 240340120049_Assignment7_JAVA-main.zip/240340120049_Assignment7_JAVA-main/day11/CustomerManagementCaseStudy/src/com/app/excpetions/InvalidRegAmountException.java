package com.app.excpetions;


public class InvalidRegAmountException extends Exception{
	
	public InvalidRegAmountException(String msg) {
		super(msg);
	}
}
