package com.app.customer;

import java.util.List;

import com.app.excpetions.CustomerException;
import com.app.excpetions.InvalidPasswordException;
import com.app.validateInputs.ValidateAllInputs;

public class CustomerFunctions {
	
	public static Customer signIn(String custEmail, String pass, List<Customer> cust) throws CustomerException, InvalidPasswordException{
		findByEmail(custEmail, cust);
		ValidateAllInputs.validateUserPass(pass);
		Customer c = findByEmail(custEmail, cust);
		validatePass(custEmail,pass,cust);
		return new Customer(c.getFirstName(), c.getLastName(), c.getCustEmail(), c.getCustPass(), c.getRegAmount(), c.getCustDob(), c.getPlan());
	}

	public static Customer findByEmail(String custEmail, List<Customer> custList) throws CustomerException, InvalidPasswordException{
		Customer email = new Customer(custEmail);
		int index = custList.indexOf(email);
		if(index == -1) {
			throw new CustomerException("Invalid email..not found!!");
		}
		return custList.get(index);
	}
	
	public static boolean validatePass(String custEmail, String custPass,List<Customer> cust) throws CustomerException, InvalidPasswordException  {
		Customer c = findByEmail(custEmail, cust);
		if(!(custPass.equals(c.getCustPass()))) {
			throw new CustomerException("Password is not matching!! pls try again with valid pass..");
		}
		return true;
	}	
	
	public static void changePass(String custEmail, String oldPass, String newPass,List<Customer> cust) throws CustomerException, InvalidPasswordException {
		Customer c2 = findByEmail(custEmail, cust);
		
		boolean match = validatePass(custEmail, oldPass, cust);
		if(!match) {
			throw new CustomerException("Old pass is not matching...");
		}
		c2.setCustPass(newPass);
	}
}
