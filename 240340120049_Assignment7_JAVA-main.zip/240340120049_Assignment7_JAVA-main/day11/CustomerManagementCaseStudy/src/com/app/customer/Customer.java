package com.app.customer;
/* 1.Customer should be assigned system generated (auto increment) customer id : int
Store - first name, last name email(string),password(string),registrationAmount(double),
dob(LocalDate),plan(ServicePlan : enum)
Unique ID - email */

import java.time.LocalDate;

import com.app.servicePlans.ServicePlan;

public class Customer {
	private static int custId=1;
	private String firstName;
	private String lastName;
	private String custEmail;
	private String custPass;
	private double regAmount;
	private LocalDate custDob;
	private ServicePlan plan;
	private int num;
	
	public Customer(String firstName, String lastName, String custEmail, String custPass, double regAmount,
			LocalDate custDob, ServicePlan plan) {
		super();
		num = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.custEmail = custEmail;
		this.custPass = custPass;
		this.regAmount = regAmount;
		this.custDob = custDob;
		this.plan = plan;
		custId++;
	}
	
	//added overloaded ctor to wrap up the primary key to pass as ref..
	public Customer(String custEmail) {
		this.custEmail = custEmail;
	}
	

	@Override
	public String toString() {
		return "[custId=" + num + ", firstName=" + firstName + ", lastName=" + lastName + ", custEmail="
				+ custEmail + ", custPass=" + custPass + ", regAmount=" + regAmount + ", custDob=" + custDob + ", plan="
				+ plan + "]";
	}
	
	//it will invoke when indexOf method will call...
	@Override
	public boolean equals(Object o) {
		if(o instanceof Customer) {
			Customer c = (Customer)o;
			return this.custEmail.equals(c.custEmail);
		}
		return false;
	}

	public static int getCustId() {
		return custId;
	}

	public static void setCustId(int custId) {
		Customer.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustPass() {
		return custPass;
	}

	public void setCustPass(String custPass) {
		this.custPass = custPass;
	}

	public double getRegAmount() {
		return regAmount;
	}

	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}

	public LocalDate getCustDob() {
		return custDob;
	}

	public void setCustDob(LocalDate custDob) {
		this.custDob = custDob;
	}

	public ServicePlan getPlan() {
		return plan;
	}

	public void setPlan(ServicePlan plan) {
		this.plan = plan;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	

	
	
}
