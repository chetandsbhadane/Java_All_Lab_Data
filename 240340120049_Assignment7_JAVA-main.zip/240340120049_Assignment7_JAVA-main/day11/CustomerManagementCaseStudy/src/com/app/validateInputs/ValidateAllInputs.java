package com.app.validateInputs;

import java.time.LocalDate;
import java.util.regex.Pattern;

import com.app.customer.Customer;
import com.app.excpetions.InvalidEmailFormatException;
import com.app.excpetions.InvalidPasswordException;
import com.app.excpetions.InvalidRegAmountException;
import com.app.servicePlans.ServicePlan;

public class ValidateAllInputs {

	public static Customer validateInputs(String firstName, String lastName, String custEmail, String custPass,
			double regAmount, String custDob, String plan) throws InvalidRegAmountException, InvalidEmailFormatException, InvalidPasswordException{
			
		ServicePlan plans = validateServicePlan(plan); //plans = 1000.0
		validateRegAmount(plans, regAmount);
		validateEmailId(custEmail);
		validateUserPass(custPass);
		return new Customer(firstName, lastName, custEmail, custPass, regAmount, LocalDate.parse(custDob), plans);
	}
	
	public static ServicePlan validateServicePlan(String plans) throws IllegalArgumentException{
		return ServicePlan.valueOf(plans.toUpperCase());
	}
	
	public static void validateRegAmount(ServicePlan plans ,double regAmt) throws InvalidRegAmountException{
		if(!(regAmt == plans.getPlanPrice())) {
			throw new InvalidRegAmountException("Reg Amount Sould be Matched with plans amt" + plans.getPlanPrice());
		}
	}
	
//	4.4 email must contain @ and it should end with either .com | .org | .net
	public static boolean validateEmailId(String email) throws InvalidEmailFormatException{
		String Emailpattern = "[a-z]+[a-z0-9]+@[a-z]+.[com|org|net]"; //chetan09@gmail.com
		if(!(email.matches("(.*)"+Emailpattern+"(.*)"))) {
			throw new InvalidEmailFormatException("Email format doesnt match please try format for eg chetan09@gmail.com");
		}
		return true;
	}
	
	public static boolean validateUserPass(String custPass) throws InvalidPasswordException {
	       String custPattern = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])"+ "(?=.*[@#$%^&+=])"+ "(?=\\S+$).{8,20}$";
	       if(!(custPass.matches("(.*)"+custPattern+"(.*)"))) {
	    	   throw new InvalidPasswordException("a digit must occur at least once.\r\n"
	    	   		+ "a lower case alphabet must occur at least once.\r\n"
	    	   		+ " an upper case alphabet that must occur at least once.\r\n"
	    	   		+ "a special character that must occur at least once.\r\n"
	    	   		+ "white spaces don’t allowed in the entire string.\r\n"
	    	   		+ "at least 8 characters and at most 20 characters." + "\n\ne.g Chetu@bhadane09");
	       }
		return true;
	}
}
