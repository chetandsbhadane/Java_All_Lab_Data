package com.app.customer;
import java.time.LocalDate;

import com.app.customExceptions.PasswordMismatchException;

public class Customer {
	private int custId;
	private String fName;
	private String custEmail;
	private String custPass;
	private ServicePlan serviceType;
	private LocalDate dob;
	private LocalDate creationDate;
	private double regAmt;
	
	public Customer(int custId, String fName, String custEmail, String custPass,ServicePlan serviceType, LocalDate dob,
			double regAmt) {
		super();
		this.custId = custId;
		this.fName = fName;
		this.custEmail = custEmail;
		this.custPass = custPass;
		this.serviceType = serviceType;
		this.dob = dob;
		this.creationDate = LocalDate.now();
		this.regAmt = regAmt;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", fName=" + fName + ", custEmail=" + custEmail + ", pass= " + custPass + " ,serviceType=" + serviceType + ", dob="
				+ dob + ", creationDate=" + creationDate + ", regAmt=" + regAmt + "]";
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}
	
	
	
	public String getCustPass() {
		return custPass;
	}

	public void setCustPass(String custPass) {
		this.custPass = custPass;
	}

	public void changePass(Customer c, String oldPass, String newPass) throws PasswordMismatchException {
		String oldpass = c.getCustPass();
		if(!(oldpass.equals(oldPass))) {
			throw new PasswordMismatchException("Password is not matching with older one try again later..");
		}
		c.setCustPass(newPass);
	}
	
}
