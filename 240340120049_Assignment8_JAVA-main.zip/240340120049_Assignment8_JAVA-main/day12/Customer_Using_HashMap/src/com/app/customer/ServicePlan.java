package com.app.customer;

public enum ServicePlan {
	SILVER(1000),GOLD(2000),DIAMOND(3000),PLATINUM(5000);
	
	private double planPrice;
	private ServicePlan(double planPrice) {
		this.planPrice = planPrice;
	}
	
	@Override
	public String toString() {
		return "plan- " + planPrice;
	}

	public double getPlanPrice() {
		return planPrice;
	}

	public void setPlanPrice(double planPrice) {
		this.planPrice = planPrice;
	}
	
	
}
