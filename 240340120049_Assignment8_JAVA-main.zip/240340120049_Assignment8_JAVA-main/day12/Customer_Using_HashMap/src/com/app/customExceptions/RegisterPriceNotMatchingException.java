package com.app.customExceptions;

public class RegisterPriceNotMatchingException extends Exception{
	public RegisterPriceNotMatchingException(String msg) {
		super(msg);
	}
}
