package com.app.customExceptions;

public class CustomerException extends Exception{
	public CustomerException(String msg) {
		super(msg);
	}
}
