package com.app.customExceptions;

public class InvalidEmailFormatException extends Exception{
	public InvalidEmailFormatException(String msg) {
		super(msg);
	}
}
