package com.app.customExceptions;

public class PasswordMismatchException extends Exception{
	public PasswordMismatchException(String msg) {
		super(msg);
	}
}
