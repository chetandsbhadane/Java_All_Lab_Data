package com.app.customExceptions;

public class invalidAcNotFoundException extends Exception{
	public invalidAcNotFoundException(String msg) {
		super(msg);
	}
}
