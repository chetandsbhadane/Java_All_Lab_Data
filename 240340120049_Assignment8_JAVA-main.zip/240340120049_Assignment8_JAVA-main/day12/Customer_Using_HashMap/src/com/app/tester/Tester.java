package com.app.tester;

import java.util.Map;
import java.util.Scanner;

import com.app.customExceptions.CustomerException;
import com.app.customer.Customer;
import com.app.utils.AllValidations;
import com.app.utils.UtilsCustomer;

public class Tester {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			Map<Integer, Customer> mapCustData = UtilsCustomer.populateData();
			int ch = 0;
			do {
				System.out.println("1.Create Account\n2.displayAll\n3.Fetch Ac Summary\n4.Change Password\n5.unsubscribe customer");
				ch = sc.nextInt();
				try {
					switch (ch) {
					case 1:
						System.out.println("Enter Details: CustId, CustName, email, ServiceType, DOB, RegAmt");
						Customer c = AllValidations.allInputValidations(sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.next(),
								sc.next(), sc.nextDouble());
						mapCustData.put(c.getCustId(), c);
						System.out.println("Customer has been added!");
						break;
						
					case 2:
						System.out.println("All Customers");
						for(Customer cust:mapCustData.values()) {
							System.out.println(cust);
						}
						System.out.println("\n");
						break;
						
					case 3:
						System.out.println("Enter CustId to fetch the details..");
						System.out.println(UtilsCustomer.findByCustId(sc.nextInt(), mapCustData));
						break;
						
					case 4:
						System.out.println("Enter CustId and old and new pass to change password..");
						Customer c2 = UtilsCustomer.findByCustId(sc.nextInt(), mapCustData);
						c2.changePass(c2, sc.next(), sc.next());
						System.out.println("password has been changed!");
						break;
						
						//un-subscribe or remove
					case 5:
						System.out.println("Enter cust id to un-subscribe customer..");
						Customer custRemove = mapCustData.remove(sc.nextInt());
						if(custRemove==null) {
							throw new CustomerException("Invalid custId, Customer cant be un-subscribe");
						}
						System.out.println("customer has been un-subscribe");
						break;
					}
				} catch (Exception e) {
					sc.nextLine();
					System.out.println("pls try again.." + e);
				}
			} while (ch != 0);

		}
	}
}
