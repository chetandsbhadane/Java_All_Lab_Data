package com.app.utils;

import java.time.LocalDate;

import com.app.customExceptions.InvalidEmailFormatException;
import com.app.customExceptions.RegisterPriceNotMatchingException;
import com.app.customer.Customer;
import com.app.customer.ServicePlan;


public class AllValidations {
	
	public static Customer allInputValidations(int custId, String fName, String custEmail,String custPass, String servicePlan, String dob,
			double regAmt) throws InvalidEmailFormatException, RegisterPriceNotMatchingException {
		
		ServicePlan type = validatePlan(servicePlan);
		validateRegPrice(type,regAmt);
		validateEmail(custEmail);
		return new Customer(custId, fName, custEmail,custPass, type, LocalDate.parse(dob), regAmt);
	}
	
	public static boolean validateEmail(String email) throws InvalidEmailFormatException{
		String emailPattern = "[a-z]+[a-z0-9]+@[a-z]+.[com|org|net]";
		if(!(email.matches("(.*)"+emailPattern+"(.*)"))) {
			throw new InvalidEmailFormatException("Email format doesnt match please try format for eg. chetan09@gmail.com");
		}
		return true;
	}
	
	public static ServicePlan validatePlan(String plan) throws IllegalArgumentException{
		return ServicePlan.valueOf(plan.toUpperCase());
	}
	
	public static void validateRegPrice(ServicePlan plan,double price) throws RegisterPriceNotMatchingException {
		if(plan.getPlanPrice()!=price) {
			throw new RegisterPriceNotMatchingException("Register price is not matching with plans price..");
		}
	}
}
