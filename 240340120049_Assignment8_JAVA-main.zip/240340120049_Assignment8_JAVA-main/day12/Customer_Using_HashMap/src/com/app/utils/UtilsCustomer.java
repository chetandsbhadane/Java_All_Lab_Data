package com.app.utils;

import java.util.HashMap;
import java.util.Map;

import com.app.customExceptions.invalidAcNotFoundException;
import com.app.customer.Customer;
import static java.time.LocalDate.parse;
import static com.app.customer.ServicePlan.*;


public class UtilsCustomer {
	
	public static Customer findByCustId(int custId,Map<Integer, Customer> mapData) throws invalidAcNotFoundException {
		Customer custid = mapData.get(custId);
		if(custid == null) {
			throw new invalidAcNotFoundException("Invalid account number");
		}
		return custid;
	}
	
	public static Map<Integer, Customer> populateData() {
		HashMap<Integer, Customer> mapData = new HashMap<>();
		mapData.put(101, new Customer(101, "Chetan", "chetan09@gmail.com","chetu", PLATINUM, parse("2000-09-16"), 5000));
		mapData.put(102, new Customer(102, "Kiran", "kiran@gmail.com","kiran", SILVER, parse("1999-01-21"), 1000));
		mapData.put(10,new Customer(10, "a2", "b2@gmail.com","b2", GOLD, parse("1990-01-21"), 2000));
		mapData.put(34,new Customer(34, "a3", "b3@gmail.com","b3", SILVER, parse("1990-04-20"), 1000));
		mapData.put(20,new Customer(20, "a4", "b4@gmail.com","a4", GOLD, parse("1992-10-21"), 2000));
		mapData.put(50,new Customer(50, "a5", "b5@gmail.com", "b5",SILVER, parse("1995-11-21"), 1000));
		mapData.put(10,new Customer(10, "a22", "b22@gmail.com","a22", PLATINUM, parse("1993-01-21"), 5000));
		return mapData;
	}
}
