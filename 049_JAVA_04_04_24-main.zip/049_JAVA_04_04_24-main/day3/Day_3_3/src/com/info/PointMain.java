package com.info;

import java.util.Scanner;


/*2. Show following options
 * Options : 
1. Plot a point
Inputs : array index , x  ,y
Check boundary conditions  , check if some point is already plotted at the same index , if not then store the point details.
In case of any errors , display suitable error message.

2.   Display x,y co-ordinates of all the points plotted so far ,using for-each loop.

0. Exit */
public class PointMain {

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			System.out.println("How many points to create: ");

			Point2D[] points = new Point2D[sc.nextInt()];

			for (int i = 0; i < points.length; i++) {

				System.out.println("Enter x coordinates: ");
				double x = sc.nextDouble();
				System.out.println("Enter y coordinates: ");
				double y = sc.nextDouble();
				points[i] = new Point2D(x, y);

				for (int j = 0; j <= i - 1; j++) {
					if (points[i].isEqaul(points[j])) {
						points[i] = null;
						System.out.println("These Coordinates already exists");
						System.out.println("i = " + i);
						i--;
						System.out.println("i = " + i);
						break;
					}
				}
			}
			for (Point2D p : points) {
				System.out.println(p.show());
			}
			sc.close();
		}

	}

