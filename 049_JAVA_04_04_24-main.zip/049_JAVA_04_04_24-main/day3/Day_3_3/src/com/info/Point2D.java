package com.info;

import java.util.Scanner;

/*
3rd day

1. Prompt user , how many points to plot? 
Create suitable array. (Hint : array of references)

2. Show following options

Options : 
1. Plot a point
Inputs : array index , x  ,y
Check boundary conditions  , check if some point is already plotted at the same index , if not then store the point details.
In case of any errors , display suitable error message.

2.   Display x,y co-ordinates of all the points plotted so far ,using for-each loop.

0. Exit */
public class Point2D {
	private double x;
	private double y;

	public Point2D(double X, double Y){
		x = X;
		y = Y;
	}

	public String show(){
		return "x = " + this.x + " " + " y = " + this.y;
	}
	
	
	public boolean isEqaul(Point2D obj){
		return (this.x == obj.x && this.y == obj.y);	
	}

	
	public double calculateDistance(Point2D obj){ //d=√((x2 – x1)² + (y2 – y1)²).
		return Math.sqrt(Math.pow(obj.x - x,2) + Math.pow(obj.y-y,2));
	}
}


















