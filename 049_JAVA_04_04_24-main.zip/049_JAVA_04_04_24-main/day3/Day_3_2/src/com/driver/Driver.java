package com.driver;
//2.1   Create a driver  class(for UI)  , in the "tester" package "TestPoints" , with main(..) 

public class Driver {
	private double x;
	private double y;

	public Driver(double X, double Y){
		x = X;
		y = Y;
	}

	public String show(){
		return "x = " + this.x + " " + " y = " + this.y;
	}
	
	public boolean isEqaul(Driver obj){
		return (this.x == obj.x && this.y == obj.y);	
	}


	public double calculateDistance(Driver obj){ //d=√((x2 – x1)² + (y2 – y1)²).
		return Math.sqrt(Math.pow(obj.x - x,2) + Math.pow(obj.y-y,2));
	}
}
