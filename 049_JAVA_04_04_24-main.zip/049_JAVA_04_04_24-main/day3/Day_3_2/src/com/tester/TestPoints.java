package com.tester;

import java.util.Scanner;

import com.driver.Driver;

public class TestPoints {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Driver t1 = new Driver(sc.nextDouble(),sc.nextDouble());
		Driver t2 = new Driver(sc.nextDouble(),sc.nextDouble());

		//System.out.println(t1.show());
		System.out.println(t1.isEqaul(t2));

		System.out.println(t1.calculateDistance(t2));
	}

}
