package com.developers.geometry;
/*
1. Modify yesterday's Point2D's assignment
Re factor (modify) n add Point2D class under the package - com.developers.geometry
Add TestPoints class under the package - com.tester
Make necessary changes .

2.1   Create a driver  class(for UI)  , in the "tester" package "TestPoints" , with main(..) */

public class Point2D {
	private double x;
	private double y;

	public Point2D(double X, double Y){
		x = X;
		y = Y;
	}

	public String show(){
		return "x = " + this.x + " " + " y = " + this.y;
	}
	
	public boolean isEqaul(Point2D obj){
		return (this.x == obj.x && this.y == obj.y);	
	}


	public double calculateDistance(Point2D obj){ //d=√((x2 – x1)² + (y2 – y1)²).
		return Math.sqrt(Math.pow(obj.x - x,2) + Math.pow(obj.y-y,2));
	}
	
}
