package com.tester;

import java.util.Scanner;

import com.developers.geometry.Point2D;

public class TestPoint {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter x1 and y1");
		Point2D t1 = new Point2D(sc.nextDouble(),sc.nextDouble());
		System.out.println("Enter x2 and y2");
		Point2D t2 = new Point2D(sc.nextDouble(),sc.nextDouble());

		//System.out.println(t1.show());
		System.out.println(t1.isEqaul(t2));

		System.out.println(t1.calculateDistance(t2));

	}

}
