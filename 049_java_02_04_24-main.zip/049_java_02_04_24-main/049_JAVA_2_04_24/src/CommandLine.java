
class CommandLine{

	public static void main(String[] args){
		int number1 = Integer.parseInt(args[0]);
		int number2 = Integer.parseInt(args[1]);
		System.out.println(number1+number2);
	}
}