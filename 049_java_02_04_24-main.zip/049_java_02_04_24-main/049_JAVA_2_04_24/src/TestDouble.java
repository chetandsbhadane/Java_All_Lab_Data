/*1 Accept 2 double values from User (using Scanner). Check data type.
. If arguments are not doubles , supply suitable error message & terminate.
If numbers are double values , print its average.
Hint : Method of Scanner to use : hasNextDouble , nextDouble */
import java.util.Scanner;

class TestDouble{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		double d1=0.0,d2=0.0;
		if(sc.hasNextDouble()){
			d1=sc.nextDouble();
		}
		else{
			System.out.println("Entered no is not double");
		sc.close();
		System.exit(0);
	
		}
		if(sc.hasNextDouble()){
			d2=sc.nextDouble();
		}
		else{
			System.out.println("Entered no is not double");
		sc.close();
		System.exit(0);
		}

		double avg = (d1+d2)/2;
		System.out.println("Average of doubles is: " + avg);		

	}

}