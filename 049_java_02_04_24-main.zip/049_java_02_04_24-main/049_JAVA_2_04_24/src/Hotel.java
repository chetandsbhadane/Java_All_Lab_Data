/* 2 Display food menu to user. User will select items from menu along with the quantity. 
(eg 1. Dosa 2. Samosa 3. Idli ... 10 . Generate Bill ) Assign fixed prices to food items(hard code the prices)
When user enters 'Generate Bill' option(10) , display total bill & exit. */

import java.util.Scanner;
class Hotel{
	public static void main(String[] args){
		Scanner sc= new Scanner(System.in);
	
		int choice=0,quantity=0;
		float price=0;
		double totalPrice=0;
		do{
			System.out.println("Menu: 1.Dosa-20\n2.Samosa-30\n3.Idli-40\n4.poha-20\n5.chai-10\n6.coffe-15\n7.upama-20\n8.sandwich-50\n9.kachori-15\n10.GenerateBill");
			System.out.println("Enter your choice:");
			choice = sc.nextInt();
			switch(choice){
				case 1: 
					price = 20;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 2: 
					price = 30;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 3: 
					price = 40;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 4: 
					price = 20;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 5: 
					price = 10;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 6: 
					price = 15;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 7: 
					price = 20;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 8: 
					price = 50;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 9: 
					price = 15;
					System.out.println("Enter quantity: ");
					quantity = sc.nextInt();
					totalPrice = totalPrice + (price*quantity);
					break;
				case 10:
					System.out.println("-----Your Bill-----");
					System.out.println("Total Bill is: " + totalPrice);
					sc.close();
					System.exit(0);
			}
		}while(choice!=10);
	}

}