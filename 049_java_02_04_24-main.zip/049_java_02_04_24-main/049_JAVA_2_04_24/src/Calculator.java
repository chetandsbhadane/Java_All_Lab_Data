/*
Create java application for the following
Accept 2 numbers from user & operation to perform
1. Add 2.Subtract 3. Multiply 4.Divide 5.Exit
Display the result of the operation. 
Java app must continue to run till user chooses exit option. */

import java.util.Scanner;
class Calculator{
	public static void main(String [] a){
		Scanner sc = new Scanner(System.in);
		double number1=0,number2=0;
		int ch=0;
		do{
			System.out.println("<-------Welcome to Calci------->");
			System.out.println("1. Add 2.Subtract 3. Multiply 4.Divide 5.Exit");
			ch = sc.nextInt();
			System.out.println("Enter First Number");
			number1 = sc.nextDouble();
			System.out.println("Enter Second Number");
			number2 = sc.nextDouble();
			switch(ch){
				case 1:
					double sum = number1+number2;
					System.out.println("The Addition is "+ sum);
					break;
				case 2:
					double sub = number1-number2;
					System.out.println("The Substraction is "+ sub);
					break;
				case 3:
					double mul = number1*number2;
					System.out.println("The Multiplication is "+ mul);
					break;
				case 4:
					double div = number1/number2;
					System.out.println("The Division is "+ div);
					break;
				case 5:
					System.exit(0);
				default:
					System.out.println("Enter only from given menu..");
			}
		}while(ch!=5);
	}

}