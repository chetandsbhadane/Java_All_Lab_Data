package com.app.fruits;

public class Apple extends Fruit{

	private boolean fresh;
	
	public Apple(String color, double weight, String name, boolean fresh) {
		super(color, weight, name,fresh);
		this.fresh = fresh;
		
	}
	
	public String jam() {
		return " " + getName() + getColor() + " making jam!";
	}
	
	public boolean getFresh() {
		return fresh;
	}
	
	public boolean setFresh(boolean fresh) {
		return this.fresh = fresh;
	}
	
	public String toString() {
		System.out.println("in apple cls");
		return super.toString() + " " + fresh;
	}
	
	public String taste() {
		return "sweet n sour";
	}
}
