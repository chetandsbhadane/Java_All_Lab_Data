package com.app.fruits;

public class Orange extends Fruit{
	private boolean fresh;
	public Orange(String color, double weight, String name, boolean fresh) {
		super(color, weight, name,fresh);
		this.fresh = fresh;
	}
	
	public String juice() {
		return getName() + getColor() + "extracting juice!!";
	}
	
	public boolean getFresh() {
		return fresh;
	}
	
	public boolean setFresh(boolean fresh) {
		return this.fresh = fresh;
	}
	
	public String toString() {
		return super.toString() + " " + fresh;
	}
	
	public String taste() {
		return "sour";
	}
}
