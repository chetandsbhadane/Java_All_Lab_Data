package com.app.fruits;

/*
4.1 Can you arrange Fruit,Apple,Orange,Mango in inheritance hierarchy ?
Use tight encapsulation.

4.2 Properties (instance variables)  : color : String , weight : double , 
name:String, fresh : boolean

4.3 Add suitable constructor

4.4 Override  toString correctly to return state of all fruits 
		(return only  : name ,color , weight )   
		
4.5 Add a taste() method : public String taste()

For Fruit : Can you identify taste of any general fruit ? NO
So add a taste() with this definition : returns "no specific taste" 
OR is there any BETTER solution ????

Apple : should return  "sweet n sour"
Mango : should return  "sweet"
Orange : should return  "sour" 

4.6 Add specific functionality , in the sub classes
In Mango : public void pulp() {Display name n color of the fruit + a mesg  creating  pulp!}
In Orange : public void juice() {Display name n weight of the fruit + a mesg extracting juice!}
In Apple : public void jam() {Display name of the fruit + a mesg  making jam!}

4.7 Add all of above classes under the package "com.app.fruits"
4.8 Create java application FruitBasket , with main method , as a tester
4.9 Prompt user for the basket size n create suitable data structure
*/
public class Fruit {
	private String color;
	private double weight;
	private String name;
	private boolean fresh;
	
	public Fruit(String color,double weight,String name,boolean fresh) {
		this.color = color;
		this.weight = weight;
		this.name = name;
	}
	
	//getter...
	public String getColor() {
		return color;
	}
	public String getName() {
		return name;
	}
	
	public boolean getFresh() {
		return false;
	}
	
	public String toString() {
		System.out.println("in fruit clss");
		return name + " " + color + " " + weight;
	}
	
	public String taste() {
		return "No specific";
	}
	
	public boolean setFresh(boolean fresh) {
		return this.fresh = fresh;
	}
	

}
