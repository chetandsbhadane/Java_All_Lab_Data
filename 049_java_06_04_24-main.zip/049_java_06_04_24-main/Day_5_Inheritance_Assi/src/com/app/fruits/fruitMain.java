package com.app.fruits;

import java.util.Scanner;

//4.9 Prompt user for the basket size n create suitable data structure
/*
 * 4.10 Supply options
1. Add Mango
2. Add Orange
3. Add Apple
NOTE : You will be ALWAYS adding a fresh fruit in the basket , in all of above options.

4. Display names of all fruits in the basket.
------------------------------------------------------------------------------

5. Display name,color,weight , taste of all fresh fruits , in the basket.
======================================================================
6. Mark a fruit in a basket , as stale(=not fresh)
i/p : index 
o/p : error message (in case of invalid index) or mark it stale

7. Mark all sour fruits stale 
Hint : Use equals() method of the String class.

8. Invoke fruit specific functionality (pulp / juice / jam)
i/p : index
Invoke correct functionality (pulp / juice / jam)

9. Exit 
*/
public class fruitMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size for basket..");
		int size = sc.nextInt();
		Fruit[] f = new Fruit[size];
		int counter=0;
		int ch = 0;
		int index=0;
		do {
			System.out.println("Enter choice \n1.Add Mango\n2.Add Orange\n3.Add Apple\n4.Display"
					+ " All Fruits.\n5.display taste\n6.Stale or not\n7.make sour to stale\n8.fruit functionality..");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				if(counter < f.length) {
					System.out.println("enter color, weight, name and fresh or not");
					f[counter] = new Mango(sc.next(), sc.nextDouble(), sc.next(), sc.nextBoolean());
					if(f[counter].getFresh() == true) {
						counter++;
						System.out.println("Mango is added");
					}
					else {
						System.out.println("only fresh fruits can be added!");
					}
					
				}
				else {
					System.out.println("Basket is full..");
				}
				break;

			case 2:
				if(counter < f.length) {
					System.out.println("enter color, weight, name and fresh or not");
					f[counter] = new Orange(sc.next(), sc.nextDouble(), sc.next(), sc.nextBoolean());
					if(f[counter].getFresh() == true) {
						counter++;
						System.out.println("Orange is added");
					}
					else {
						System.out.println("only fresh fruits can be added!");
					}
					
				}
				else {
					System.out.println("Basket is full..");
				}
				break;
				
			case 3:
				if(counter < f.length) {
					System.out.println("enter color, weight, name and fresh or not");
					f[counter] = new Apple(sc.next(), sc.nextDouble(), sc.next(), sc.nextBoolean());
					if(f[counter].getFresh() == true) {
						counter++;
						System.out.println("Apple is added");
					}
					else {
						System.out.println("only fresh fruits can be added!");
					}
				}
				else {
					System.out.println("Basket is full..");
				}
				break;
				
			case 4:
				System.out.println("All Fruits details");
				for (Fruit fruits : f)
					if (fruits != null)
						System.out.println(fruits);
				break;
				
			case 5:
				System.out.println("All Fruits and its taste");
				for(Fruit fruits : f) {
					if (fruits != null)
						System.out.println(fruits + " " +fruits.taste());
				}
				break;
				
			case 6: 
				//6. Mark a fruit in a basket , as stale(=not fresh)
//			i/p : index 
//			o/p : error message (in case of invalid index) or mark it stale
				System.out.println("Enter an index");
				index = sc.nextInt();
				if(index < f.length) {
					if(f[index].getFresh() == true) {  //magn-0,appl-1,orange-3 1==true
						System.out.println("Stale..");
						f[index].setFresh(false);
					}
					else {
						System.out.println("fresh fruit..");
					}
				}
				else {
					System.out.println("Invalid Index..");
				}
				break;
				
//				7. Mark all sour fruits stale 
//				Hint : Use equals() method of the String class.
			case 7:
				for(Fruit fruits : f) {
					if(fruits.taste().equals("sour")) {
						fruits.setFresh(false);
					}
				}
				System.out.println("All sour fruits are marked as stale..");
				break;
				
			case 8:
//				8. Invoke fruit specific functionality (pulp / juice / jam)
//				i/p : index
//				Invoke correct functionality (pulp / juice / jam)
				System.out.println("enter index that you want to invoke the functionality of");
				index=sc.nextInt();
				if(index < f.length) {
					if(f[index] instanceof Mango) {
						System.out.println(((Mango)f[index]).pulp());
					}
					else if(f[index] instanceof Orange) {
						System.out.println(((Orange)f[index]).juice());
					}
					else if(f[index] instanceof Apple) {
						System.out.println(((Apple)f[index]).jam());
					}

				}
				else {
					System.out.println("Invalid Index...");
				}
				break;
			}
		}while(ch != 0);
	
	}

}
