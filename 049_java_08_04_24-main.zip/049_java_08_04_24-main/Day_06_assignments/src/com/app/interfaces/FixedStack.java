package com.app.interfaces;

import com.app.customer.Customer;

public class FixedStack implements Stack{
	
	private Customer[] cArr ;
	public int current;
	public FixedStack(int size) {
		cArr = new Customer[size];
		current = 0;
	}
	
	@Override
	public void push(Customer cust) {
		cArr[current++] = cust;
	}

	@Override
	public Customer pop() {
		return cArr[--current];
	}
	
	@Override
	public void top() {
		if(current <=0 ) {
			System.out.println("stack is empty");
		}else {
			System.out.println(cArr[current-1]);
		}
	}

	
}
