package com.app.interfaces;

import com.app.customer.Customer;

/*Steps
5.1  Create Customer class
5.2 Stack interface -- push & pop functionality for Customer refs. & declare STACK_SIZE as a constant. 
5.3 Create implementation class of Stack i/f -- FixedStack (array based)
5.4 Create another implementation class of Stack i/f-- GrowableStack (array based)*/

public interface Stack {
	int STACK_SIZE = 2;

	public void push(Customer cust);
	
	public Customer pop();
	
	public void top();
}
