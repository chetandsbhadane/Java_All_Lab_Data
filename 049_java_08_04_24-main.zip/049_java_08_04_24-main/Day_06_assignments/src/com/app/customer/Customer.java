package com.app.customer;
/*5. OPTIONAL Hands on 
(Main objective :Run time polymorphism achieved using interfaces)
Create Java application for fixed stack & growable stack based on Stack i/f , for storing customer details

Customer has : id(int), name (string) , address(string)
Provide suitable constructor n toString 
Customer has : id(int), name (string) , address(string)
Provide suitable constructor n toString

Steps
5.1  Create Customer class
5.2 Stack interface -- push & pop functionality for Customer refs. & declare STACK_SIZE as a constant. 
5.3 Create implementation class of Stack i/f -- FixedStack (array based)
5.4 Create another implementation class of Stack i/f-- GrowableStack (array based)
*/
public class Customer {
	private int id;
	private String name;
	private String address;
	
	public Customer(int id, String name, String address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	
	
	
}
