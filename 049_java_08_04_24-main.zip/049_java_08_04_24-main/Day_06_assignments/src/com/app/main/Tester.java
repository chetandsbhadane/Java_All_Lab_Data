package com.app.main;

import java.util.Scanner;

import com.app.customer.Customer;
import com.app.interfaces.FixedStack;

/*5.5 
Create Tester class : TestStacks
Display Menu
Note : Must use 1 switch-case only. You won't need any complex nested control structure
Once user selects either fixed or growable stack , user shouldn't be allowed to change the selection of the stack.

1 -- Choose Fixed Stack

2 -- Choose Growable Stack*/
public class Tester {

	public static void main(String[] args) {
		int ch1=0;
		int ch2=0;
		FixedStack fArr=null;
		Customer cust =null;
		Scanner sc = new Scanner(System.in);
//		fArr.push(cust);
//		fArr.push( new Customer(2,"wsde","retet"));
//		fArr.pop();
//		fArr.top();
		
		do {
			System.out.println("1.Fixed Stack\n2.Growable Stack\n3.push\n4.top\n5.pop\n6.exit");
			ch1 = sc.nextInt();
			switch(ch1) {
				case 1:
					System.out.println("Enter how many customer do you want to add?");
					int size=sc.nextInt();
					fArr = new FixedStack(size);
					break;
				case 2:
					
					break;
					/*3 -- Push data 
					I/P : Accept customer details & store these details in the earlier chosen stack or give error mesg 
					: NO stack chosen !!!
					In case user has chosen fixed stack , n stack is full give err mesg. 
					In case of growable stack , should be able to save customer details w/o getting err.*/
				case 3:
					System.out.println("Enter customer Id, name, address..");
					int id=sc.nextInt();
					String name=sc.next();
					String addr=sc.next();
					//int index=0;
					//System.out.println(fArr.length);
				
					cust = new Customer(id, name, addr);
					fArr.push(cust);
					//index++;
			
					break;
					
//					4 --- Pop data & display the same (from the earlier chosen stack or give error mesg :
//						NO stack chosen !!!)
//					No inputs are required : pop customer details from the top of the stack
				case 4:
					fArr.top();
					break;
					
				case 5:
					System.out.println(fArr.pop());
					break;
			
			}
			
		}while(ch1!=6);
	}

}
