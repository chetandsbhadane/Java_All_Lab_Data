package day_6;

import java.util.Scanner;

/*Create Tester class : TestStacks
Display Menu
Note : Must use 1 switch-case only. You won't need any complex nested control structure
Once user selects either fixed or growable stack , user shouldn't be allowed to change the selection of the stack.

1 -- Choose Fixed Stack

2 -- Choose Growable Stack

3 -- Push data 
I/P : Accept customer details & store these details in the earlier chosen stack or give error mesg : 
NO stack chosen !!!
In case user has chosen fixed stack , n stack is full give err mesg. 
In case of growable stack , should be able to save customer details w/o getting err.

4 --- Pop data & display the same (from the earlier chosen stack or give error mesg : NO stack chosen !!!)
No inputs are required : pop customer details from the top of the stack

5 -- Exit */
public class TestStacks {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack st = null;
		boolean b=false;
		int ch=0;
		System.out.println("Enter Your Stack\n1.Fixed Stack\n2.Growable Stack");
		if(sc.nextInt()==1) {
			st = new FixedStack();
		}
		else {
			st = new GrowwableStack();
		}
		
		do{
			System.out.println("1.Push\n2.Pop\n3.Display Data");
			ch = sc.nextInt();
			switch(ch) {
				case 1:
					System.out.println("Enter id, name and addr..");
					Customer cust = new Customer(sc.nextInt(), sc.next(), sc.next());
					b = st.push(cust);
					if(b) {
						System.out.println("Data pushed.");
					}
					else {
						System.out.println("Stack is overflow..");
					}
					break;
					
				case 2:
					b = st.pop();
					if(b) {
						System.out.println("Eleemet removed..");
					}
					else {
						System.out.println("Stack is underflow..");
					}
					break;
				case 3:
					if(st instanceof FixedStack) {
						((FixedStack)st).display();
					}
					else if(st instanceof GrowwableStack) {
						((GrowwableStack)st).display();
					}
				
					break;
			}
		}while(ch!=5);
		
	
	}

}
