package day_6;
/*
5. OPTIONAL Hands on 
(Main objective :Run time polymorphism achieved using interfaces)
Create Java application for fixed stack & growable stack based on Stack i/f , for storing customer details

Customer has : id(int), name (string) , address(string)
Provide suitable constructor n toString

Steps
5.1  Create Customer class
5.2 Stack interface -- push & pop functionality for Customer refs. & declare STACK_SIZE as a constant. 
5.3 Create implementation class of Stack i/f -- FixedStack (array based)
5.4 Create another implementation class of Stack i/f-- GrowableStack (array based)

5.5 
Create Tester class : TestStacks
Display Menu
Note : Must use 1 switch-case only. You won't need any complex nested control structure
Once user selects either fixed or growable stack , user shouldn't be allowed to change the selection of the stack.

1 -- Choose Fixed Stack

2 -- Choose Growable Stack

3 -- Push data 
I/P : Accept customer details & store these details in the earlier chosen stack or give error mesg : 
NO stack chosen !!!
In case user has chosen fixed stack , n stack is full give err mesg. 
In case of growable stack , should be able to save customer details w/o getting err.

4 --- Pop data & display the same (from the earlier chosen stack or give error mesg : NO stack chosen !!!)
No inputs are required : pop customer details from the top of the stack

5 -- Exit */
public class Customer {
	private int id;
	private String name;
	private String addr;
	public Customer(int id, String name, String addr) {
		super();
		this.id = id;
		this.name = name;
		this.addr = addr;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", addr=" + addr + "]";
	}
	
	
}
