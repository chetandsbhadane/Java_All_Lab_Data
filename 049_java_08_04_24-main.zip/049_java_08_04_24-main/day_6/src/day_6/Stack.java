package day_6;

public interface Stack {
	int STACK_SIZE = 2;
	
	public boolean push(Customer cust);
	
	public boolean pop();
	
}
