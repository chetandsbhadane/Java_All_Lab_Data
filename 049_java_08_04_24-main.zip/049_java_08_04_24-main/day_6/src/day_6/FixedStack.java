package day_6;

public class FixedStack implements Stack{

	Customer[] cust = new Customer[STACK_SIZE];
	
	private int indexTop = -1;
	@Override
	public boolean push(Customer cust2) {
		boolean b=false;
		if(indexTop == STACK_SIZE-1) {
			b=false;
		}else {
			indexTop++;
			cust[indexTop] = cust2;
			b=true;
		}
		return b;
	}
	
	@Override
	public boolean pop() {
		boolean b = false;
		if(indexTop == -1) {
			b=false;
		}
		else {
			cust[indexTop] = null;
			indexTop--;
			b=true;
		}
		return b;

	}
	
	public void display() {
		for(Customer c:cust) {
			if(c!=null) {
				System.out.println(c.toString());
			}
		}	
	}
}
