package day_6;

import java.util.Arrays;

public class GrowwableStack implements Stack{

	Customer[] cust = new Customer[STACK_SIZE];
	private int indexTop = -1;
	@Override
	public boolean push(Customer data) {
		boolean b=false;
		if(indexTop == cust.length-1) {
			cust = Arrays.copyOf(cust, cust.length * STACK_SIZE);
			b=false;
		}
		indexTop++;
		cust[indexTop] = data;
		b=true;
		return b;
	}

	@Override
	public boolean pop() {
		boolean b = false;
		if(indexTop == -1) {
			b=false;
		}
		else {
			cust[indexTop] = null;
			indexTop--;
			b=true;
		}
		return b;
		
	}
	
	public void display() {
		for(Customer c:cust) {
			if(c!=null) {
				System.out.println(c.toString());
			}
		}
		
	}

}
